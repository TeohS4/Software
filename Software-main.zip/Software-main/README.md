Quit Smoking Android Application

This is a simple description about this project

Splash screen

user social login (google)

Dashboard(Chat, leaderboard, get help, setting, logout)

chat-user chat-send sms and email

Homepage (Countdown, Money saved, Life won, Pro tips, Achievement)

Setting page (profile,notification)

Community (join Facebook group, Community forum – text and upload photo, )

Achievement page

Leaderboard

Get help (local clinics, consultant)

Admin Dashboard: add achievment, add tips

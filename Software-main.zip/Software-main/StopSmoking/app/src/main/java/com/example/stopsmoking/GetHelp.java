package com.example.stopsmoking;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class GetHelp extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_get_help);

        getSupportActionBar().hide();
    }
}